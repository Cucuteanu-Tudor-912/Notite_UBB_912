//
// Created by theo on 19.04.2023.
//

#ifndef A45_913_FINTINA_OLIVIA_MAIN_TESTALL_H
#define A45_913_FINTINA_OLIVIA_MAIN_TESTALL_H

void testDomain();
void testRepository();
void testController();
void testTrenchCoatExists();

#endif //A45_913_FINTINA_OLIVIA_MAIN_TESTALL_H
